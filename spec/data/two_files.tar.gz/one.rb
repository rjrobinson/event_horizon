a = 1
b = 2
puts a + b
